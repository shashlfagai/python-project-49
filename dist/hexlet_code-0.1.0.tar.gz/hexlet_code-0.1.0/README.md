### Hexlet tests and linter status:
[![Actions Status](https://github.com/shashlfagai/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/shashlfagai/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/bbba6cdef933a9f1f16d/maintainability)](https://codeclimate.com/github/shashlfagai/python-project-49/maintainability)
https://asciinema.org/a/q4gzMEYxMP6zx78nWd8wGtt6x
https://asciinema.org/a/yolZFWMJ7aktjrWlv0WYMnyaJ
https://asciinema.org/a/frbSihgLOJapNANWkLz0anCyc
https://asciinema.org/a/OXmDKtwDgTMQYeCH3rB19kUJ2
