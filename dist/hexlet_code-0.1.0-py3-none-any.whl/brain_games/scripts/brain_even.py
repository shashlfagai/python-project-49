from ..even import even_number_game


def main():
    even_number_game()


if __name__ == '__main__':
    main()
